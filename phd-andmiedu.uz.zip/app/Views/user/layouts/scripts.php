<!-- Bootstrap core JavaScript -->
<script src="<?= $this->base_url('assets/vendor/jquery/jquery.min.js') ?>"></script>
<script src="<?= $this->base_url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>

<!-- DataTables JS -->
<script src="<?= $this->base_url('assets/vendor/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?= $this->base_url('assets/vendor/datatables/dataTables.bootstrap4.min.js') ?>"></script>

<!-- Core plugin JavaScript -->
<script src="<?= $this->base_url('assets/vendor/jquery-easing/jquery.easing.min.js') ?>"></script>
<!-- Select2 JS -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>

<!-- Custom scripts for all pages -->
<script src="<?= $this->base_url('assets/js/sb-admin-2.min.js') ?>"></script>

<!-- Page level plugins -->
<script src="<?= $this->base_url('assets/vendor/chart.js/Chart.min.js') ?>"></script>
<script src="<?= $this->base_url('assets/js/index.global.min.js') ?>"></script>
<script src="<?= $this->base_url('assets/js/notyf.min.js') ?>"></script>
<script src="<?= $this->base_url('assets/js/tasks.js') ?>"></script>
<script src="<?= $this->base_url('assets/vendor/js/script.js') ?>"></script>
