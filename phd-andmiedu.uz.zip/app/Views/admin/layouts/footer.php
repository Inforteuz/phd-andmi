<!-- Footer -->
<footer class="sticky-footer bg-white" style="width: 100%;">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span class="footer-version">Tizim versiyasi: 1.0.0</span><br><br>
      <span>&copy; PhD-DsC Hisobot Platformasi | <?php echo date('Y'); ?> | Dasturchi: <a href="https://t.me/Oyatillo_52" class="footer-link">Anvarov Oyatillo</a></span>
    </div>
  </div>
</footer>
